# 🤖#100DaysOfCode - Twitter Bot
A simple Twitter bot to favourite all things #100DaysOfCode. If you want to build your own, you can follow the tutorial I wrote [here](https://medium.freecodecamp.org/how-i-built-a-twitter-bot-for-100daysofcode-768ef5e12405). Get stuck?! [Tweet me](https://twitter.com/raynesio), I don't bite.

**TLDR;**

*QUICK START* The hashtag to search by and the number of tweets to be favourited can be set by adjusting the 'q' and 'count' parameters in the app.js file.

```javascript
q: '#100daysofcode'
count: 25
```

🔥🔥🔥
